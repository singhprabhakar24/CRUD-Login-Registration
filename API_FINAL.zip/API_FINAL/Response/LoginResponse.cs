﻿using Microsoft.Identity.Client;

namespace API_FINAL.Response
{
    public class LoginResponse
    {
        public string username { get; set; } = string.Empty;

        public string password { get; set; } = string.Empty;

       
    }
}
